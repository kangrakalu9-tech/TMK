VK Hardware & Plywoods — GitHub Pages website

FILES
- index.html: website homepage
- assets/logo.svg: logo graphic

PUBLISH ON GITHUB PAGES
1. Sign in to GitHub and create a new public repository.
2. Upload index.html and the assets folder (keep the same folder structure).
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish your website. The URL will appear in Settings → Pages.

Google Search Console
The Google site-verification meta tag is included in the <head> of index.html.
After the GitHub Pages site is live, add/verify the exact website URL in Search Console.

Update store details or photos by editing index.html and the assets folder.
